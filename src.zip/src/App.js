
import TodoListWrap from './components/TodoListWrap';
import './App.scss';

function App() {
  return (
    <div>
        <TodoListWrap></TodoListWrap>
    </div>
  );
}

export default App;
